using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class GameEndManager : MonoBehaviour
{
    public GameObject WinImage; 
    public GameObject LoseImage; 
    public float countdownDuration = 20f; 
    public Text countdownText;
    public GameObject trueTurret;

    private bool gameEnded = false;
    private bool Touched = false;

        private void Start()
    {

        WinImage.gameObject.SetActive(false);
        LoseImage.gameObject.SetActive(false);
        StartCoroutine(StartCountdown());
    }


    IEnumerator StartCountdown()
    {
        float currentTime = countdownDuration;

        while (currentTime > 0f && !gameEnded)
        {
            UpdateCountdownText(currentTime);
            yield return new WaitForSeconds(1f);
            currentTime -= 1f;
        }

        if (!gameEnded)
        {
            EndGame(true); // 
        }
    }


    void UpdateCountdownText(float time)
    {
        countdownText.text = "Time Left: " + time.ToString("F0");
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        trueTurret.SetActive(false);
    }

    private void Update()
    {
        bool isActive = trueTurret.activeSelf;
        if(!isActive && !Touched)
        {
            EndGameLose();
        }
    }

    void EndGameLose()
    {
        Touched = true;

        LoseImage.gameObject.SetActive(true);
        StartCoroutine(SwitchSceneAfterDelay());

    }
 


    void EndGame(bool isVictory)
    {
        gameEnded = true;


        if (isVictory)
        {
            WinImage.gameObject.SetActive(true);
        }
        else
        {
            LoseImage.gameObject.SetActive(true);
        }

        countdownText.gameObject.SetActive(false);

        StartCoroutine(SwitchSceneAfterDelay());
    }


    IEnumerator SwitchSceneAfterDelay()
    {
        yield return new WaitForSeconds(2f);


        SceneManager.LoadScene("GameOverScene");
    }
}

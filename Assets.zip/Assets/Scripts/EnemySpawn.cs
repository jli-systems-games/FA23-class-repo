using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawn : MonoBehaviour
{
    public GameObject bulletPrefab;
    public Transform firePoint;
    public float minTriggerTime = 1f;
    public float maxTriggerTime = 3f; 

    private void Start()
    {
        StartCoroutine(TriggerFunction());
    }

    IEnumerator TriggerFunction()
    {
        while (true)
        {
            float triggerTime = Random.Range(minTriggerTime, maxTriggerTime);
            yield return new WaitForSeconds(triggerTime);

            Fire();

        }
    }

    void Fire()
    {
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
    }

}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerRotate : MonoBehaviour
{
    public float rotationAngle = 90f;
    public GameObject turretNormal;
    public GameObject turretFiring;
    public GameObject trueTurret;

    public GameObject bulletPrefab;
    public Transform firePoint;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.S))
        {
            RotateTurret(rotationAngle);
        }
        else if (Input.GetKeyDown(KeyCode.Space))
        {
            Fire();
        }
    }



    void RotateTurret(float angle)
    {
            float newRotation = transform.eulerAngles.z + angle;
            newRotation = Mathf.Clamp(newRotation, 0f, 360f);
            transform.eulerAngles = new Vector3(0f, 0f, newRotation);
    }

    void Fire()
    {
        turretNormal.SetActive(false);
        turretFiring.SetActive(true);
  
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Destroy(gameObject);
    }
}

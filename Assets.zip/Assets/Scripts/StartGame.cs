using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartGame : MonoBehaviour
{
    public string GameScene; 

    public void SwitchScene()
    {
        SceneManager.LoadScene(GameScene);
    }
}
